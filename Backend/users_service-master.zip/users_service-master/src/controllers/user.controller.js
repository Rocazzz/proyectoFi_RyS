const userService = require("../services/user.service");

exports.getProfile = async (req, res, next) => {
  try {
    const user = await userService.getProfile(req.user.id);
    res.json(user);
  } catch (err) {
    next(err);
  }
};

exports.updateProfile = async (req, res, next) => {
  try {
    const updated = await userService.updateProfile(req.user.id, req.body);
    res.json(updated);
  } catch (err) {
    next(err);
  }
};

exports.deleteUser = async (req, res, next) => {
  try {
    const deactivated = await userService.deleteUser(req.user.id);
    res.json({ message: "Cuenta desactivada", user: deactivated });
  } catch (err) {
    next(err);
  }
};
