const router = require("express").Router();
const { register, login } = require("../controllers/auth.controller");
const validator = require("../utils/validator");
const Joi = require("joi");

const registerSchema = Joi.object({
  name: Joi.string().required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  role: Joi.string().valid("cliente", "admin").default("cliente"),
});
const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
});

router.post("/register", validator(registerSchema), register);
router.post("/login", validator(loginSchema), login);

module.exports = router;
