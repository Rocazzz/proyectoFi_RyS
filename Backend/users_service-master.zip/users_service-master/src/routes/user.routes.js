const router = require('express').Router();
const auth = require('../middlewares/auth.middleware');
const validator = require('../utils/validator');
const Joi = require('joi');
const {
  getProfile,
  updateProfile,
  deleteUser
} = require('../controllers/user.controller');

// esquema para PUT: al menos un campo
const updateSchema = Joi.object({
  name: Joi.string().optional(),
  email: Joi.string().email().optional(),
  password: Joi.string().min(6).optional(),
}).min(1);

router.get(    '/me', auth, getProfile);
router.put(    '/me', auth, validator(updateSchema), updateProfile);  // ← nuevo
router.delete( '/me', auth, deleteUser);                              // ← nuevo

module.exports = router;
