const User = require('../models/user.model');

module.exports = {
  getByEmail:    User.findByEmail,
  getById:       User.findById,
  createUser:    User.create,
  updateUser:    User.update,
  deactivateUser: User.deactivate,
};

