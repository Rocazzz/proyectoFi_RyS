module.exports = (err,req,res,_) => {
    console.error(err);
    const status = err.status || 500;
    res.status(status).json({ message: err.message || 'Error interno' });
  };
  