const pool = require("../config/db");

module.exports = {
  findByEmail: async (email) => {
    const { rows } = await pool.query("SELECT * FROM users WHERE email=$1", [
      email,
    ]);
    return rows[0];
  },
  findById: async (id) => {
    const { rows } = await pool.query(
      "SELECT id, name, email, role, created_at FROM users WHERE id=$1",
      [id]
    );
    return rows[0];
  },
  create: async ({ name, email, passwordHash, role }) => {
    const { rows } = await pool.query(
      `INSERT INTO users (name, email, password_hash, role)
       VALUES ($1,$2,$3,$4)
       RETURNING id, name, email, role, created_at`,
      [name, email, passwordHash, role]
    );
    return rows[0];
  },
  async update(id, { name, email, passwordHash }) {
    // 1) Construye dinámicamente SET según campos recibidos
    const fields = [];
    const values = [];
    let idx = 1;
    if (name) {
      fields.push(`name = $${idx++}`);
      values.push(name);
    }
    if (email) {
      fields.push(`email = $${idx++}`);
      values.push(email);
    }
    if (passwordHash) {
      fields.push(`password_hash = $${idx++}`);
      values.push(passwordHash);
    }
    if (!fields.length) return this.findById(id); // sin cambios, devuelve perfil

    values.push(id);
    const sql = `
      UPDATE users
         SET ${fields.join(", ")}
       WHERE id = $${idx}
       RETURNING id, name, email, role, created_at
    `;
    const { rows } = await pool.query(sql, values);
    return rows[0];
  },

  async deactivate(id) {
    // Marca usuario como “disabled” o lo borras lógicamente
    const { rows } = await pool.query(
      `UPDATE users
          SET role = 'disabled'
        WHERE id = $1
      RETURNING id, name, email, role, created_at`,
      [id]
    );
    return rows[0];
  },
};
