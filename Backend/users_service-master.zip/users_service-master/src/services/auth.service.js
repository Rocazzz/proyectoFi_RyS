const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { secret, expiresIn } = require("../config/jwt");
const userRepo = require("../repositories/user.repository");

class AuthService {
  async register({ name, email, password, role }) {
    const exists = await userRepo.getByEmail(email);
    if (exists) throw { status: 409, message: "Email ya registrado" };
    const passwordHash = await bcrypt.hash(password, 10);
    return userRepo.createUser({ name, email, passwordHash, role });
  }

  async login({ email, password }) {
    const user = await userRepo.getByEmail(email);
    if (!user) throw { status: 401, message: "Credenciales inválidas" };
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) throw { status: 401, message: "Credenciales inválidas" };
    const token = jwt.sign({ id: user.id, role: user.role }, secret, {
      expiresIn,
    });
    return { token };
  }
}

module.exports = new AuthService();
