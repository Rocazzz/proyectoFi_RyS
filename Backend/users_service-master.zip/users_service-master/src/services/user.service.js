const userRepo = require("../repositories/user.repository");

class UserService {
  async getProfile(id) {
    const user = await userRepo.getById(id);
    if (!user) throw { status: 404, message: "Usuario no encontrado" };
    return user;
  }
  async updateProfile(id, data) {
    const payload = {};
    if (data.name) payload.name = data.name;
    if (data.email) payload.email = data.email;
    if (data.password)
      payload.passwordHash = await bcrypt.hash(data.password, 10);

    const user = await userRepo.updateUser(id, payload);
    if (!user) throw { status: 404, message: "Usuario no encontrado" };
    return user;
  }

  async deleteUser(id) {
    const user = await userRepo.deactivateUser(id);
    if (!user) throw { status: 404, message: "Usuario no encontrado" };
    return user;
  }
}

module.exports = new UserService();
